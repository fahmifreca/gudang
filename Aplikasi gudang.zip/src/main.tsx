import React from "react";
import ReactDOM from "react-dom/client";
import Legacy from "./Legacy";
import "./index.css";
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode><Legacy /></React.StrictMode>
);
